// popup.js

const $ = id => document.getElementById(id);

// ── Tab switching ──────────────────────────────────────────────
document.querySelectorAll('.tab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
    $('tab-' + btn.dataset.tab).classList.add('active');
  });
});

// ── Format buttons ─────────────────────────────────────────────
document.querySelectorAll('.fmt-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.fmt-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  });
});

// ── Detect current tab ─────────────────────────────────────────
async function detectPage() {
  const dot = $('status-dot');
  dot.className = 'status-dot loading';
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab.url || !tab.url.includes('instagram.com')) {
      dot.className = 'status-dot';
      return;
    }
    dot.className = 'status-dot ready';
    const url = tab.url;
    const banner = $('page-banner');
    const icon   = $('page-icon');
    const label  = $('page-label');
    if (url.match(/\/p\/|\/tv\//)) {
      icon.textContent = '📸'; label.textContent = 'Detected: Post / Photo';
    } else if (url.includes('/reel/')) {
      icon.textContent = '🎬'; label.textContent = 'Detected: Reel';
    } else if (url.includes('/stories/')) {
      icon.textContent = '📖'; label.textContent = 'Detected: Story';
    } else if (url.match(/instagram\.com\/[^/]+\/?$/) && !url.includes('/explore')) {
      icon.textContent = '👤'; label.textContent = 'Detected: Profile — switch to Profile tab';
      // auto-fill username
      const m = url.match(/instagram\.com\/([^/?#]+)/);
      if (m && m[1]) $('profile-username').value = m[1];
    } else {
      banner.classList.add('hidden'); return;
    }
    banner.classList.remove('hidden');
  } catch(e) {
    dot.className = 'status-dot';
  }
}
detectPage();

// ── Helpers ────────────────────────────────────────────────────
function showResult(msg, isError = false) {
  const box = $('quick-result');
  box.className = 'result-box' + (isError ? ' error' : '');
  box.textContent = msg;
  box.classList.remove('hidden');
  setTimeout(() => box.classList.add('hidden'), 5000);
}

async function sendToContent(action, data = {}) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return chrome.tabs.sendMessage(tab.id, { action, ...data });
}

// ── Quick actions ──────────────────────────────────────────────
$('btn-download-post').addEventListener('click', async () => {
  try {
    const res = await sendToContent('downloadPost');
    if (res?.success) showResult('✅ ' + res.message);
    else showResult('⚠ ' + (res?.message || 'Could not find media on this page.'), true);
  } catch(e) {
    showResult('⚠ Navigate to a post or reel first.', true);
  }
});

$('btn-download-story').addEventListener('click', async () => {
  try {
    const res = await sendToContent('downloadStory');
    if (res?.success) showResult('✅ ' + res.message);
    else showResult('⚠ ' + (res?.message || 'No active story detected.'), true);
  } catch(e) {
    showResult('⚠ Navigate to a story first.', true);
  }
});

$('btn-download-pfp').addEventListener('click', async () => {
  try {
    const res = await sendToContent('downloadPFP');
    if (res?.success) showResult('✅ Profile picture downloaded!');
    else showResult('⚠ ' + (res?.message || 'Navigate to a profile page.'), true);
  } catch(e) {
    showResult('⚠ Navigate to an Instagram profile first.', true);
  }
});

$('btn-copy-bio').addEventListener('click', async () => {
  try {
    const res = await sendToContent('copyBio');
    if (res?.success) {
      await navigator.clipboard.writeText(res.bio);
      showResult('✅ Bio copied to clipboard!');
    } else {
      showResult('⚠ ' + (res?.message || 'Navigate to a profile page.'), true);
    }
  } catch(e) {
    showResult('⚠ Navigate to an Instagram profile first.', true);
  }
});

// ── Profile scraper ────────────────────────────────────────────
$('btn-load-profile').addEventListener('click', loadProfile);
$('profile-username').addEventListener('keydown', e => { if (e.key === 'Enter') loadProfile(); });

async function loadProfile() {
  let raw = $('profile-username').value.trim();
  if (!raw) return;
  raw = raw.replace(/^@/, '').replace(/.*instagram\.com\//, '').replace(/\/.*$/, '');
  if (!raw) return;

  $('btn-load-profile').textContent = '…';
  $('btn-load-profile').disabled = true;
  $('profile-preview').classList.add('hidden');

  try {
    // Ask content script to fetch profile info from the current tab or via API shim
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const result = await chrome.tabs.sendMessage(tab.id, { action: 'fetchProfileInfo', username: raw });

    if (result?.success) {
      renderProfile(result.profile);
    } else {
      alert('Could not load profile. Make sure you are on instagram.com and the username is correct.');
    }
  } catch(e) {
    // Fallback: open the profile tab and try
    const newTab = await chrome.tabs.create({ url: `https://www.instagram.com/${raw}/`, active: false });
    setTimeout(async () => {
      try {
        const result = await chrome.tabs.sendMessage(newTab.id, { action: 'fetchProfileInfo', username: raw });
        if (result?.success) renderProfile(result.profile);
        chrome.tabs.remove(newTab.id);
      } catch(_) {
        chrome.tabs.remove(newTab.id);
        alert('Could not load profile data. Try navigating to the profile page directly.');
      }
    }, 2500);
  }

  $('btn-load-profile').textContent = 'Load';
  $('btn-load-profile').disabled = false;
}

function renderProfile(p) {
  $('profile-avatar').src = p.avatarUrl || '';
  $('profile-name').textContent   = p.fullName || p.username;
  $('profile-handle').textContent = '@' + p.username;
  $('profile-stats').textContent  = `${fmt(p.posts)} posts · ${fmt(p.followers)} followers · ${fmt(p.following)} following`;
  $('profile-bio-box').textContent = p.bio || '(no bio)';
  $('profile-preview').classList.remove('hidden');
}

function fmt(n) {
  if (!n && n !== 0) return '?';
  if (n >= 1_000_000) return (n/1_000_000).toFixed(1) + 'M';
  if (n >= 1_000) return (n/1_000).toFixed(1) + 'K';
  return n.toString();
}

// ── Full profile download ──────────────────────────────────────
$('btn-download-all').addEventListener('click', startFullDownload);

async function startFullDownload() {
  const opts = {
    posts:      $('opt-posts').checked,
    reels:      $('opt-reels').checked,
    stories:    $('opt-stories').checked,
    pfp:        $('opt-pfp').checked,
    bio:        $('opt-bio').checked,
    highlights: $('opt-highlights').checked,
    username:   $('profile-username').value.trim().replace(/^@/, ''),
    format:     document.querySelector('.fmt-btn.active')?.dataset.fmt || 'zip',
  };

  if (!opts.username) return;
  $('profile-preview').classList.add('hidden');
  $('progress-section').classList.remove('hidden');
  $('progress-log').textContent = '';

  let cancelled = false;
  $('btn-cancel').onclick = () => { cancelled = true; logLine('⛔ Cancelling…'); };

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const send  = (action, extra = {}) =>
    chrome.tabs.sendMessage(tab.id, { action, username: opts.username, ...extra });

  // Make sure we're on the profile page
  if (!tab.url?.includes(opts.username)) {
    logLine(`ℹ Opening profile page for @${opts.username}…`);
  }

  let totalFiles = 0;
  const steps = buildSteps(opts);
  const isZip = opts.format === 'zip';
  const zipKey = isZip ? (opts.username + '_' + Date.now()) : '';

  // Tell content script which download mode to use
  await send('setDlMode', { mode: opts.format, zipKey });

  for (let i = 0; i < steps.length; i++) {
    if (cancelled) break;
    const step = steps[i];
    setProgress(Math.round((i / steps.length) * 100), step.label);
    logLine('⏳ ' + step.label);

    try {
      const res = await send(step.action);

      if (step.action === 'scrapePostList') {
        const count = res?.count || res?.posts?.length || 0;
        logLine(`   Found ${count} posts/videos`);

      } else if (step.action === 'dlPosts' || step.action === 'dlReels' || step.action === 'dlStories') {
        const n = res?.downloaded ?? 0;
        totalFiles += n;
        logLine(`   ✅ Downloaded ${n} file${n !== 1 ? 's' : ''}`);

      } else if (step.action === 'dlProfilePic') {
        if (res?.ok !== false) { totalFiles++; logLine('   ✅ Profile picture saved'); }
        else logLine('   ⚠ ' + (res?.message || 'PFP not found'));

      } else if (step.action === 'dlBioJson') {
        if (res?.ok !== false) logLine('   ✅ Bio JSON saved');
        else logLine('   ⚠ Could not fetch bio');

      } else {
        if (res?.ok !== false) logLine('   ✅ Done');
      }
    } catch(e) {
      logLine('   ⚠ ' + e.message);
    }
  }

  if (!cancelled) {
    if (isZip) {
      setProgress(95, 'Creating ZIP archive…');
      logLine('⏳ Compressing files into ZIP…');
      try {
        const zipRes = await send('zipFinalize', {
          zipKey,
          zipFilename: `eloe/${opts.username}/${opts.username}_eloe.zip`,
        });
        if (zipRes?.ok) logLine(`   ✅ ZIP saved (${zipRes.files} files)`);
        else logLine('   ⚠ ZIP error: ' + (zipRes?.error || 'unknown'));
      } catch(e) {
        logLine('   ⚠ ZIP failed: ' + e.message);
      }
    }
    setProgress(100, 'All done!');
    logLine(`✅ Finished! ${totalFiles} files saved to Downloads/eloe/${opts.username}/`);
    saveHistory(opts.username, opts);
  }

  setTimeout(() => {
    $('progress-section').classList.add('hidden');
    $('profile-preview').classList.remove('hidden');
  }, 5000);
}

function buildSteps(opts) {
  const steps = [];
  // Profile picture first — single quick call
  if (opts.pfp)     steps.push({ label: 'Downloading profile picture (HD)…', action: 'dlProfilePic' });
  // Bio JSON
  if (opts.bio)     steps.push({ label: 'Fetching bio & profile info…',      action: 'dlBioJson' });
  // Scrape the full post list via API pagination (must come before dlPosts/dlReels)
  if (opts.posts || opts.reels)
                    steps.push({ label: 'Fetching full post list via API…',   action: 'scrapePostList' });
  // Download posts (images + videos)
  if (opts.posts)   steps.push({ label: 'Downloading posts & photos…',        action: 'dlPosts' });
  // Download reels (filtered subset of posts)
  if (opts.reels)   steps.push({ label: 'Downloading reels…',                 action: 'dlReels' });
  // Stories
  if (opts.stories)   steps.push({ label: 'Downloading active stories…',        action: 'dlStories' });
  if (opts.highlights)steps.push({ label: 'Downloading story highlights…',      action: 'dlHighlights' });
  return steps;
}

function setProgress(pct, text) {
  $('progress-bar').style.width = pct + '%';
  $('progress-text').textContent = text;
  $('progress-pct').textContent  = pct + '%';
}

function logLine(msg) {
  const log = $('progress-log');
  log.innerHTML += msg + '\n';
  log.scrollTop = log.scrollHeight;
}

// ── History ────────────────────────────────────────────────────
function saveHistory(username, opts) {
  chrome.storage.local.get(['history'], ({ history = [] }) => {
    history.unshift({
      username, time: Date.now(),
      items: Object.keys(opts).filter(k => opts[k] === true).join(', ')
    });
    chrome.storage.local.set({ history: history.slice(0, 20) });
    renderHistory(history);
  });
}

function renderHistory(history) {
  const list  = $('history-list');
  const empty = $('history-empty');
  list.innerHTML = '';
  if (!history.length) { empty.classList.remove('hidden'); return; }
  empty.classList.add('hidden');
  history.forEach(h => {
    const d = new Date(h.time);
    const el = document.createElement('div');
    el.className = 'history-item';
    el.innerHTML = `
      <span class="history-thumb">👤</span>
      <div class="history-info">
        <div class="history-name">@${h.username}</div>
        <div class="history-meta">${d.toLocaleDateString()} · ${h.items}</div>
      </div>
      <span class="history-badge">done</span>`;
    list.appendChild(el);
  });
}

chrome.storage.local.get(['history'], ({ history = [] }) => renderHistory(history));

$('btn-clear-history').addEventListener('click', () => {
  chrome.storage.local.set({ history: [] });
  renderHistory([]);
});

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ════════════════════════════════════════════════════════════
// DMs TAB
// ════════════════════════════════════════════════════════════

const dmEl = {
  scan:       () => $('btn-dm-scan'),
  threadList: () => $('dm-thread-list'),
  empty:      () => $('dm-empty'),
  options:    () => $('dm-options'),
  progress:   () => $('dm-progress'),
  fill:       () => $('dm-prog-fill'),
  progText:   () => $('dm-prog-text'),
  progPct:    () => $('dm-prog-pct'),
  log:        () => $('dm-log'),
  loadMore:   () => $('btn-dm-load-more'),
  exportBtn:  () => $('btn-dm-export'),
  dmsName:    () => $('dms-name'),
  dmsCount:   () => $('dms-count'),
  dmsPhotos:  () => $('dms-photos'),
  dmsVideos:  () => $('dms-videos'),
  dmsReels:   () => $('dms-reels'),
  dmsAudio:   () => $('dms-audio'),
};

let _selectedThread = null;

// ── Scan inbox ───────────────────────────────────────────────
$('btn-dm-scan').addEventListener('click', async () => {
  dmEl.scan().textContent = '…';
  dmEl.scan().disabled    = true;
  dmEl.empty().classList.add('hidden');
  dmEl.options().classList.add('hidden');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    // If not on instagram.com/direct, open inbox in background tab to trigger API
    if (!tab.url?.includes('instagram.com/direct')) {
      dmLog('Opening DM inbox to trigger API…');
      const bg = await chrome.tabs.create({ url: 'https://www.instagram.com/direct/inbox/', active: false });
      await sleep(3000);
      try {
        const res = await chrome.tabs.sendMessage(bg.id, { action: 'dmScanInbox' });
        chrome.tabs.remove(bg.id);
        handleScanResult(res);
      } catch(_) {
        chrome.tabs.remove(bg.id);
        dmShowEmpty();
      }
    } else {
      const res = await chrome.tabs.sendMessage(tab.id, { action: 'dmScanInbox' });
      handleScanResult(res);
    }
  } catch(e) {
    dmShowEmpty();
  }

  dmEl.scan().textContent = '🔍 Scan Inbox';
  dmEl.scan().disabled    = false;
});

function handleScanResult(res) {
  if (!res?.ok || !res.threads?.length) { dmShowEmpty(); return; }
  renderThreadList(res.threads);
}

function dmShowEmpty() {
  dmEl.empty().classList.remove('hidden');
  dmEl.threadList().style.display = 'none';
}

// ── Render thread list ───────────────────────────────────────
function renderThreadList(threads) {
  const list = dmEl.threadList();
  list.innerHTML = '';
  list.style.display = 'flex';
  dmEl.empty().classList.add('hidden');

  for (const t of threads) {
    const el = document.createElement('div');
    el.className = 'dm-thread-item';
    el.dataset.threadId = t.threadId;

    const avatarEl = document.createElement('div');
    avatarEl.className = 'dm-thread-avatar';
    if (t.avatar) {
      const img = document.createElement('img');
      img.src = t.avatar;
      img.onerror = () => { avatarEl.textContent = '👤'; };
      avatarEl.appendChild(img);
    } else {
      avatarEl.textContent = '👤';
    }

    el.innerHTML += '';
    el.appendChild(avatarEl);
    el.insertAdjacentHTML('beforeend', `
      <div class="dm-thread-info">
        <div class="dm-thread-name">${escHtml(t.title)}</div>
        <div class="dm-thread-prev">${escHtml(t.snippet || 'Tap to select')}</div>
      </div>
      <span class="dm-thread-count">${t.count ? t.count + ' msgs' : ''}</span>
    `);

    el.addEventListener('click', () => selectThread(t, el));
    list.appendChild(el);
  }
}

// ── Select a thread ──────────────────────────────────────────
async function selectThread(t, el) {
  document.querySelectorAll('.dm-thread-item').forEach(i => i.classList.remove('sel'));
  el.classList.add('sel');
  _selectedThread = t;

  dmEl.options().classList.remove('hidden');
  dmEl.dmsName().textContent   = t.title;
  dmEl.dmsCount().textContent  = t.count || '…';
  dmEl.dmsPhotos().textContent = '—';
  dmEl.dmsVideos().textContent = '—';
  dmEl.dmsReels().textContent  = '—';
  dmEl.dmsAudio().textContent  = '—';
}

// ── Load all pages ───────────────────────────────────────────
$('btn-dm-load-more').addEventListener('click', async () => {
  if (!_selectedThread?.threadId) return;
  dmEl.loadMore().disabled = true;
  dmEl.loadMore().textContent = '…loading';
  dmEl.progress().classList.remove('hidden');
  dmEl.options().classList.add('hidden');
  dmProgSet(10, 'Fetching all message pages…');
  dmLog('Paginating thread — this may take a moment for long chats…');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const res = await chrome.tabs.sendMessage(tab.id, {
      action: 'dmLoadThread', threadId: _selectedThread.threadId
    });
    dmProgSet(100, 'Done!');
    if (res?.ok) {
      dmEl.dmsCount().textContent  = res.count;
      dmEl.dmsPhotos().textContent = res.stats?.photo ?? '—';
      dmEl.dmsVideos().textContent = res.stats?.video ?? '—';
      dmEl.dmsReels().textContent  = (res.stats?.reel ?? '—') + ' (links only)';
      dmEl.dmsAudio().textContent  = res.stats?.voice ?? '—';
      dmLog(`✅ Loaded ${res.count} messages.${res.hasMore ? ' (Some older messages may remain)' : ' Full history!'}`);
    } else {
      dmLog('⚠ ' + (res?.error || 'Could not load thread. Open the conversation in Instagram first.'));
    }
  } catch(e) {
    dmLog('⚠ Error: ' + e.message);
  }

  setTimeout(() => dmEl.progress().classList.add('hidden'), 1500);
  dmEl.options().classList.remove('hidden');
  dmEl.loadMore().disabled = false;
  dmEl.loadMore().textContent = '⬇ Load All Pages';
});

// ── Export ───────────────────────────────────────────────────
$('btn-dm-export').addEventListener('click', async () => {
  if (!_selectedThread?.threadId) return;
  dmEl.exportBtn().disabled = true;
  dmEl.options().classList.add('hidden');
  dmEl.progress().classList.remove('hidden');
  dmProgSet(5, 'Starting export…');
  dmLog('Exporting conversation…');
  dmLog('📸 Photos & videos will download. Reels saved as links in JSON.');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    dmProgSet(30, 'Downloading media files…');
    const res = await chrome.tabs.sendMessage(tab.id, {
      action: 'dmExport', threadId: _selectedThread.threadId
    });
    dmProgSet(95, 'Saving JSON…');
    await sleep(500);
    dmProgSet(100, 'Done!');
    if (res?.ok) {
      dmLog(`✅ Exported ${res.messages} messages.`);
      dmLog(`   📁 ${res.downloaded} media files downloaded to Downloads/eloe/DMs/`);
      dmLog(`   📄 JSON saved as ${_selectedThread.title}_conversation.json`);
      saveHistory(_selectedThread.title, { dms: true });
    } else {
      dmLog('⚠ ' + (res?.error || 'Export failed.'));
    }
  } catch(e) {
    dmLog('⚠ ' + e.message);
  }

  setTimeout(() => {
    dmEl.progress().classList.add('hidden');
    dmEl.options().classList.remove('hidden');
  }, 4000);
  dmEl.exportBtn().disabled = false;
});

// ── DM helpers ───────────────────────────────────────────────
function dmProgSet(pct, text) {
  dmEl.fill().style.width    = pct + '%';
  dmEl.progText().textContent = text;
  dmEl.progPct().textContent  = pct + '%';
}
function dmLog(msg) {
  const log = dmEl.log();
  log.textContent += msg + '\n';
  log.scrollTop = log.scrollHeight;
}
function escHtml(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
