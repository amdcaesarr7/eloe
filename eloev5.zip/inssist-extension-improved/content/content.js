// eloe content.js — v5
// Developer-perspective approach:
//
// HOW INSTAGRAM LOADS MEDIA:
//   Posts/Reels  → JSON from /api/v1/feed/user/ or /api/v1/media/{id}/info/
//                  Contains image_versions2.candidates[] and video_versions[]
//                  Full signed CDN URLs: scontent.cdninstagram.com or *.fbcdn.net
//
//   Stories      → JSON from /api/v1/feed/reels_media/ or /api/v1/feed/user_reels/
//                  Same structure: image_versions2 + video_versions
//                  Video served as progressive MP4 (206 Partial Content) from fbcdn.net
//                  URL has: efg=, _nc_vs=, oh=, oe= (expires at oe= unix timestamp)
//
//   Highlights   → /api/v1/highlights/{userId}/highlights_tray/  → reel IDs
//                  Then /api/v1/feed/reels_media/?reel_ids={ids}  → actual items
//
//   The VIDEO URL in the JSON is the exact same URL the browser fetches for playback.
//   We don't need to intercept the MP4 request — we just need the URL from the JSON.
//
// STRATEGY:
//   1. Hook fetch() in page context to capture ALL JSON API responses
//   2. From each JSON, extract every media URL (image + video) and store by context
//   3. When user clicks download, we already have the correct signed URLs
//   4. Download via background (bypasses CORS, streams directly to disk)
//
// LANGUAGE: JavaScript (MV3 content script + service worker)
// No DOM media scraping. No guessing. URLs come from the same API calls IG uses.

// ─────────────────────────────────────────────────────────────────────────────
// STATE
// ─────────────────────────────────────────────────────────────────────────────

const _profiles   = {};   // username → profileObj
const _posts      = {};   // username → [mediaItem]
const _stories    = {};   // userId   → [mediaItem]
const _highlights = {};   // userId   → { tray: [reel], items: {reelId: [mediaItem]} }
const _dmThreads  = {};   // threadId → threadObj
const _dmInbox    = [];

// mediaItem shape: { url, type:'image'|'video', shortcode, caption, width, height }

// ─────────────────────────────────────────────────────────────────────────────
// PAGE-CONTEXT FETCH HOOK
// Injected as inline <script> so it runs in page context (not isolated world)
// and can see window.fetch before Instagram replaces it.
// ─────────────────────────────────────────────────────────────────────────────

(function injectHook() {
  const s = document.createElement('script');
  s.textContent = `(function(){
  'use strict';
  const relay = (type, data) => window.postMessage({ __eloe: true, type, data }, '*');

  // Which API URLs carry useful media JSON
  const MEDIA_URLS = [
    '/api/v1/feed/user/',
    '/api/v1/feed/reels_media',
    '/api/v1/feed/user_reels',
    '/api/v1/media/',
    '/api/v1/highlights/',
    '/api/v1/feed/timeline',
    'web_profile_info',
    'graphql/query',
    '/direct_v2/inbox',
    '/direct_v2/threads/',
  ];

  const orig = window.fetch;
  window.fetch = async function(...args) {
    const res = await orig.apply(this, args);
    try {
      const url = typeof args[0] === 'string' ? args[0] : (args[0]?.url || '');
      const hit  = MEDIA_URLS.some(p => url.includes(p));
      if (hit && res.headers.get('content-type')?.includes('json')) {
        res.clone().json().then(j => relay('apiJson', { url, json: j })).catch(()=>{});
      }
    } catch(_){}
    return res;
  };

  // Also hook XHR (IG uses fetch mostly but some older paths use XHR)
  const XO = XMLHttpRequest.prototype.open;
  const XS = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(m, url, ...r) {
    this.__eloeUrl = url; return XO.apply(this, [m, url, ...r]);
  };
  XMLHttpRequest.prototype.send = function(...args) {
    this.addEventListener('load', function() {
      try {
        const url = this.__eloeUrl || '';
        if (MEDIA_URLS.some(p => url.includes(p))) {
          const j = JSON.parse(this.responseText);
          relay('apiJson', { url, json: j });
        }
      } catch(_){}
    });
    return XS.apply(this, args);
  };
})();`;
  (document.head || document.documentElement).prepend(s);
  s.remove();
})();

// ─────────────────────────────────────────────────────────────────────────────
// PROCESS INTERCEPTED JSON
// ─────────────────────────────────────────────────────────────────────────────

window.addEventListener('message', ev => {
  if (!ev.data?.__eloe) return;
  const { type, data } = ev.data;
  if (type === 'apiJson') _handleApiJson(data.url, data.json);
});

function _handleApiJson(url, j) {
  // ── Profile info ──
  const profileUser = j?.data?.user || j?.graphql?.user;
  if (profileUser?.username) {
    _profiles[profileUser.username] = _mapUser(profileUser);
    // First-page posts from graphql
    const edges = profileUser.edge_owner_to_timeline_media?.edges;
    if (edges?.length) _addPosts(profileUser.username, edges.map(e => e.node).filter(Boolean).flatMap(_nodeToItems));
  }

  // ── Feed: /api/v1/feed/user/{userId}/ ──
  if (j?.items?.length && url.includes('/feed/user/')) {
    const first = j.items[0];
    const uname = first?.user?.username;
    if (uname) _addPosts(uname, j.items.flatMap(_feedItemToItems));
  }

  // ── Stories: /api/v1/feed/reels_media/ ──
  if (j?.reels_media?.length) {
    for (const reel of j.reels_media) {
      const userId = String(reel.user?.pk || reel.id || '');
      if (userId && reel.items?.length) {
        if (!_stories[userId]) _stories[userId] = [];
        for (const item of reel.items) {
          const m = _storyItemToMedia(item);
          if (m && !_stories[userId].find(x => x.id === m.id)) _stories[userId].push(m);
        }
        // Also store by username
        const uname = reel.user?.username;
        if (uname) _stories[uname] = _stories[userId];
      }
    }
  }

  // ── Stories via user_reels ──
  if (j?.reels && typeof j.reels === 'object') {
    for (const [reelId, reel] of Object.entries(j.reels)) {
      const userId = String(reel.user?.pk || reelId);
      if (!_stories[userId]) _stories[userId] = [];
      for (const item of (reel.items || [])) {
        const m = _storyItemToMedia(item);
        if (m && !_stories[userId].find(x => x.id === m.id)) _stories[userId].push(m);
      }
      const uname = reel.user?.username;
      if (uname) _stories[uname] = _stories[userId];
    }
  }

  // ── Highlights tray ──
  if (j?.tray?.length && url.includes('highlights')) {
    const userId = String(j.tray[0]?.user?.pk || '');
    if (userId) {
      if (!_highlights[userId]) _highlights[userId] = { tray: [], items: {} };
      _highlights[userId].tray = j.tray.map(h => ({ id: h.id, title: h.title, coverUrl: h.cover_media?.thumbnail_src }));
    }
  }

  // ── Highlight reel items (returned by reels_media with highlight reel_ids) ──
  if (j?.reels_media?.length && url.includes('highlight')) {
    for (const reel of j.reels_media) {
      const reelId = reel.id;
      const userId = String(reel.user?.pk || '');
      if (!userId || !reelId) continue;
      if (!_highlights[userId]) _highlights[userId] = { tray: [], items: {} };
      _highlights[userId].items[reelId] = (reel.items || []).map(_storyItemToMedia).filter(Boolean);
    }
  }

  // ── Single media info: /api/v1/media/{id}/info/ ──
  if (j?.items?.length && url.includes('/media/') && url.includes('/info/')) {
    const item = j.items[0];
    const uname = item?.user?.username;
    if (uname) _addPosts(uname, _feedItemToItems(item));
  }

  // ── DMs ──
  if (j?.inbox?.threads) {
    _dmInbox.length = 0;
    for (const t of j.inbox.threads) {
      _dmInbox.push({ threadId: t.thread_id, title: _dmTitle(t), avatar: t.users?.[0]?.profile_pic_url || '', snippet: t.last_permanent_item?.text || '' });
      _processDMThread(t);
    }
  }
  if (j?.thread?.thread_id) _processDMThread(j.thread);
}

// Best video URL: pick highest bitrate from video_versions array
// IG provides: [{ width, height, url, type }] sorted best-first usually
function _bestVideo(versions) {
  if (!versions?.length) return null;
  // Sort by width*height descending to get highest res
  return versions.slice().sort((a, b) => (b.width * b.height) - (a.width * a.height))[0]?.url || null;
}

// Best image: highest resolution candidate
function _bestImage(image_versions2) {
  const candidates = image_versions2?.candidates;
  if (!candidates?.length) return null;
  return candidates.slice().sort((a, b) => (b.width * b.height) - (a.width * a.height))[0]?.url || null;
}

// Convert a /feed/user/ item to our mediaItem format
function _feedItemToItems(item) {
  const code    = item.code || item.pk || String(item.id || Date.now());
  const caption = item.caption?.text || '';
  const results = [];

  if (item.carousel_media?.length) {
    item.carousel_media.forEach((m, i) => {
      const isVid = m.media_type === 2;
      results.push({
        id:        String(m.id || code + '_' + i),
        url:       isVid ? _bestVideo(m.video_versions) : _bestImage(m.image_versions2),
        thumb:     _bestImage(m.image_versions2),
        type:      isVid ? 'video' : 'image',
        shortcode: code + '_' + i,
        caption,
      });
    });
    return results;
  }

  const isVid = item.media_type === 2;
  results.push({
    id:        String(item.id || code),
    url:       isVid ? _bestVideo(item.video_versions) : _bestImage(item.image_versions2),
    thumb:     _bestImage(item.image_versions2),
    type:      isVid ? 'video' : 'image',
    shortcode: code,
    caption,
  });
  return results;
}

// Convert a graphql edge node
function _nodeToItems(n) {
  const caption  = n.edge_media_to_caption?.edges?.[0]?.node?.text || '';
  const children = n.edge_sidecar_to_children?.edges || [];
  if (children.length) {
    return children.map((c, i) => {
      const cn = c.node;
      return { id: cn.id, url: cn.is_video ? (cn.video_url || cn.display_url) : cn.display_url, thumb: cn.display_url, type: cn.is_video ? 'video' : 'image', shortcode: n.shortcode + '_' + i, caption };
    });
  }
  return [{ id: n.id, url: n.is_video ? (n.video_url || n.display_url) : n.display_url, thumb: n.display_url, type: n.is_video ? 'video' : 'image', shortcode: n.shortcode, caption }];
}

// Convert a story/highlight item
// Stories use same image_versions2 / video_versions structure as posts
function _storyItemToMedia(item) {
  if (!item) return null;
  const isVid = item.media_type === 2;
  const url   = isVid ? _bestVideo(item.video_versions) : _bestImage(item.image_versions2);
  if (!url) return null;
  return {
    id:    String(item.id || item.pk || Date.now()),
    url,
    thumb: _bestImage(item.image_versions2),
    type:  isVid ? 'video' : 'image',
    taken: item.taken_at,
  };
}

function _addPosts(username, items) {
  if (!_posts[username]) _posts[username] = [];
  const seen = new Set(_posts[username].map(p => p.id));
  for (const item of items) {
    if (item?.url && !seen.has(item.id)) { seen.add(item.id); _posts[username].push(item); }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// MESSAGE ROUTER
// ─────────────────────────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    switch (msg.action) {
      case 'downloadPost':     sendResponse(await quickDownloadPost());              break;
      case 'downloadStory':    sendResponse(await quickDownloadStory());             break;
      case 'downloadPFP':      sendResponse(await dlProfilePic(null, true));        break;
      case 'copyBio':          sendResponse(await getBio());                        break;
      case 'fetchProfileInfo': sendResponse(await fetchProfileInfo(msg.username));  break;
      case 'dlProfilePic':     sendResponse(await dlProfilePic(msg.username));      break;
      case 'dlBioJson':        sendResponse(await dlBioJson(msg.username));         break;
      case 'scrapePostList':   sendResponse(await fetchAllPosts(msg.username));     break;
      case 'dlPosts':          sendResponse(await dlPosts(msg.username, false));    break;
      case 'dlReels':          sendResponse(await dlPosts(msg.username, true));     break;
      case 'dlStories':        sendResponse(await dlStories(msg.username));         break;
      case 'dlHighlights':     sendResponse(await dlHighlights(msg.username));      break;
      case 'setDlMode':        setDlMode(msg.mode, msg.zipKey); sendResponse({ ok: true }); break;
      case 'zipFinalize':      sendResponse(await chrome.runtime.sendMessage({ action: 'zipFinalize', zipKey: msg.zipKey, zipFilename: msg.zipFilename })); break;
      case 'dmScanInbox':      sendResponse(dmScanInbox());                         break;
      case 'dmLoadThread':     dmLoadThread(msg.threadId).then(sendResponse);       break;
      case 'dmExport':         dmExport(msg.threadId).then(sendResponse);           break;
      default: sendResponse({ success: false, message: 'Unknown action' });
    }
  })();
  return true;
});

// ─────────────────────────────────────────────────────────────────────────────
// DOWNLOAD ENGINE
// ─────────────────────────────────────────────────────────────────────────────

let _dlMode   = 'folder';
let _dlZipKey = '';

function setDlMode(mode, zipKey) { _dlMode = mode || 'folder'; _dlZipKey = zipKey || ''; }

async function dl(url, filename) {
  if (!url) return { ok: false, error: 'No URL' };
  filename = _san(filename);

  // blob: → convert to base64 here (tab-scoped, SW can't access them)
  if (url.startsWith('blob:')) {
    try {
      const blob = await fetch(url).then(r => r.blob());
      return dl(await _toBase64(blob), filename);
    } catch(e) { return { ok: false, error: e.message }; }
  }

  if (_dlMode === 'zip' && _dlZipKey) {
    const action = url.startsWith('data:') ? 'zipAddBase64' : 'zipAddUrl';
    return chrome.runtime.sendMessage({ action, zipKey: _dlZipKey, url, filename });
  }

  if (url.startsWith('data:')) return chrome.runtime.sendMessage({ action: 'downloadBase64', base64: url, filename });
  return chrome.runtime.sendMessage({ action: 'download', url, filename });
}

// ─────────────────────────────────────────────────────────────────────────────
// AUTHENTICATED FETCH — sends session cookies = works for private accounts
// ─────────────────────────────────────────────────────────────────────────────

function _csrf() { return (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || ''; }

function igFetch(url, opts = {}) {
  return fetch(url, {
    credentials: 'include',
    headers: { 'x-ig-app-id': '936619743392459', 'x-csrftoken': _csrf(), 'x-requested-with': 'XMLHttpRequest', 'accept': 'application/json, */*', ...opts.headers },
    ...opts,
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// PROFILE INFO
// ─────────────────────────────────────────────────────────────────────────────

async function fetchProfileInfo(username) {
  if (username && _profiles[username]) return { success: true, profile: _profiles[username] };
  try {
    const res = await igFetch(`https://i.instagram.com/api/v1/users/web_profile_info/?username=${encodeURIComponent(username)}`);
    if (res.ok) { const j = await res.json(); const u = j?.data?.user; if (u) { const p = _mapUser(u); _profiles[username] = p; return { success: true, profile: p }; } }
  } catch(_) {}
  try {
    const sr = await igFetch(`https://i.instagram.com/api/v1/users/search/?query=${encodeURIComponent(username)}`);
    if (sr.ok) {
      const sj = await sr.json();
      const found = (sj?.users || []).find(u => u.username?.toLowerCase() === username.toLowerCase());
      if (found?.pk) {
        const ir = await igFetch(`https://i.instagram.com/api/v1/users/${found.pk}/info/`);
        if (ir.ok) { const ij = await ir.json(); if (ij?.user) { const p = _mapUser(ij.user, true); _profiles[username] = p; return { success: true, profile: p }; } }
      }
    }
  } catch(_) {}
  return { success: false };
}

function _mapUser(u, fromInfo = false) {
  return {
    username:   u.username,
    fullName:   u.full_name,
    bio:        u.biography || u.biography_with_entities?.raw_text || '',
    followers:  fromInfo ? u.follower_count  : u.edge_followed_by?.count,
    following:  fromInfo ? u.following_count : u.edge_follow?.count,
    posts:      fromInfo ? u.media_count     : u.edge_owner_to_timeline_media?.count,
    avatarUrl:  u.hd_profile_pic_url_info?.url || u.profile_pic_url_hd || u.profile_pic_url,
    isPrivate:  u.is_private,
    isVerified: u.is_verified,
    userId:     String(u.pk || u.id || ''),
    website:    u.external_url,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// FETCH ALL POSTS via /api/v1/feed/user/ (stable, cursor-paginated)
// ─────────────────────────────────────────────────────────────────────────────

async function fetchAllPosts(username) {
  const info   = await fetchProfileInfo(username);
  const userId = info?.profile?.userId;
  if (!userId) return { ok: false, error: 'Cannot resolve userId for @' + username };

  const existing = new Set((_posts[username] || []).map(p => p.id));
  let nextMaxId  = null;
  let hasMore    = true;
  let pages      = 0;

  while (hasMore && pages < 60) {
    try {
      const url = `https://i.instagram.com/api/v1/feed/user/${userId}/?count=50${nextMaxId ? '&max_id=' + nextMaxId : ''}`;
      const res = await igFetch(url);
      if (!res.ok) break;
      const j   = await res.json();
      // _handleApiJson already called via hook for this fetch IF the hook is active.
      // Call directly here too so we don't miss it (hook is page-context, this is isolated).
      for (const item of (j.items || [])) {
        if (!existing.has(String(item.id))) {
          existing.add(String(item.id));
          _addPosts(username, _feedItemToItems(item));
        }
      }
      nextMaxId = j.next_max_id || null;
      hasMore   = !!nextMaxId && j.more_available !== false;
      pages++;
      await _sleep(350);
    } catch(e) { break; }
  }

  return { ok: true, count: (_posts[username] || []).length, pages };
}

// ─────────────────────────────────────────────────────────────────────────────
// FETCH STORIES for a user
// Fetches the signed CDN URLs directly from the reels_media API response
// ─────────────────────────────────────────────────────────────────────────────

async function fetchStories(username) {
  const info   = await fetchProfileInfo(username);
  const userId = info?.profile?.userId;
  if (!userId) return [];

  // Try intercepted first (hook may have already captured them)
  if (_stories[username]?.length || _stories[userId]?.length) {
    return _stories[username] || _stories[userId] || [];
  }

  try {
    const res = await igFetch(`https://i.instagram.com/api/v1/feed/reels_media/?reel_ids=${userId}`);
    if (res.ok) {
      const j = await res.json();
      _handleApiJson('/api/v1/feed/reels_media/', j); // process into _stories
      await _sleep(100);
    }
  } catch(_) {}

  return _stories[username] || _stories[userId] || [];
}

// ─────────────────────────────────────────────────────────────────────────────
// FETCH HIGHLIGHTS
// ─────────────────────────────────────────────────────────────────────────────

async function fetchHighlights(username) {
  const info   = await fetchProfileInfo(username);
  const userId = info?.profile?.userId;
  if (!userId) return null;

  // Step 1: Get the highlights tray
  try {
    const trayRes = await igFetch(`https://i.instagram.com/api/v1/highlights/${userId}/highlights_tray/`);
    if (trayRes.ok) {
      const tj = await trayRes.json();
      _handleApiJson('/api/v1/highlights/', tj);
      await _sleep(200);
    }
  } catch(_) {}

  const tray = _highlights[userId]?.tray || [];
  if (!tray.length) return { tray: [], items: {} };

  // Step 2: Fetch all reel items in batches of 5
  const allItems = {};
  for (let i = 0; i < tray.length; i += 5) {
    const batch = tray.slice(i, i + 5).map(h => h.id);
    const ids   = batch.join(',');
    try {
      const res = await igFetch(`https://i.instagram.com/api/v1/feed/reels_media/?reel_ids=${ids}`);
      if (res.ok) {
        const j = await res.json();
        _handleApiJson('/api/v1/highlights/reels_media', j);
        await _sleep(300);
      }
    } catch(_) {}
  }

  return _highlights[userId] || { tray, items: {} };
}

// ─────────────────────────────────────────────────────────────────────────────
// DOWNLOAD: Posts & Reels
// ─────────────────────────────────────────────────────────────────────────────

async function dlPosts(username, reelsOnly = false) {
  let items = _posts[username] || [];
  if (!items.length) {
    const r = await fetchAllPosts(username);
    if (!r.ok) return { ok: false, error: r.error };
    items = _posts[username] || [];
  }

  const filtered  = reelsOnly ? items.filter(p => p.type === 'video') : items;
  const slug      = _san(username);
  const sub       = reelsOnly ? 'reels' : 'posts';
  let count = 0;

  for (const item of filtered) {
    if (!item.url) continue;
    const ext  = item.type === 'video' ? '.mp4' : '.jpg';
    const num  = String(++count).padStart(4, '0');
    await dl(item.url, `${slug}/${sub}/${num}_${_san(item.shortcode)}${ext}`);
    await _sleep(300);
  }
  return { ok: true, downloaded: count };
}

// ─────────────────────────────────────────────────────────────────────────────
// DOWNLOAD: Stories
// Gets the real signed fbcdn.net/cdninstagram.com URLs from the API JSON
// (same URLs the browser would fetch for playback — no DOM needed)
// ─────────────────────────────────────────────────────────────────────────────

async function dlStories(username) {
  const items = await fetchStories(username);
  if (!items.length) return { ok: false, error: 'No active stories found for @' + username };

  const slug  = _san(username);
  let count   = 0;
  for (const item of items) {
    if (!item.url) continue;
    const ext = item.type === 'video' ? '.mp4' : '.jpg';
    const num = String(++count).padStart(3, '0');
    await dl(item.url, `${slug}/stories/${num}_story${ext}`);
    await _sleep(300);
  }
  return { ok: true, downloaded: count };
}

// ─────────────────────────────────────────────────────────────────────────────
// DOWNLOAD: Highlights
// ─────────────────────────────────────────────────────────────────────────────

async function dlHighlights(username) {
  const info   = await fetchProfileInfo(username);
  const userId = info?.profile?.userId;
  if (!userId) return { ok: false, error: 'Cannot resolve userId' };

  const hl    = await fetchHighlights(username);
  const slug  = _san(username);
  let total   = 0;

  for (const reel of (hl?.tray || [])) {
    const reelItems = (_highlights[userId]?.items[reel.id]) || [];
    const reelSlug  = _san(reel.title || reel.id);
    let count = 0;
    for (const item of reelItems) {
      if (!item?.url) continue;
      const ext = item.type === 'video' ? '.mp4' : '.jpg';
      const num = String(++count).padStart(3, '0');
      await dl(item.url, `${slug}/highlights/${reelSlug}/${num}${ext}`);
      await _sleep(300);
    }
    total += count;
  }
  return { ok: true, downloaded: total, reels: (hl?.tray || []).length };
}

// ─────────────────────────────────────────────────────────────────────────────
// DOWNLOAD: Profile picture
// ─────────────────────────────────────────────────────────────────────────────

async function dlProfilePic(username, returnResult = false) {
  const user = username || location.pathname.replace(/\//g, '').split('?')[0] || 'profile';
  let avatarUrl = _profiles[user]?.avatarUrl;
  if (!avatarUrl) {
    const info = await fetchProfileInfo(user);
    avatarUrl = info?.profile?.avatarUrl;
  }
  if (avatarUrl) {
    const res = await dl(avatarUrl, `${_san(user)}/${_san(user)}_pfp.jpg`);
    if (res?.ok !== false) return returnResult ? { success: true, ok: true } : { ok: true };
  }
  return returnResult ? { success: false, message: 'Navigate to the profile page first.' } : { ok: false };
}

// ─────────────────────────────────────────────────────────────────────────────
// DOWNLOAD: Bio JSON
// ─────────────────────────────────────────────────────────────────────────────

async function dlBioJson(username) {
  const info = await fetchProfileInfo(username);
  if (!info?.success) return { ok: false, error: 'No profile data' };
  const dataUrl = await _toBase64(new Blob([JSON.stringify(info.profile, null, 2)], { type: 'application/json' }));
  await chrome.runtime.sendMessage({ action: 'downloadBase64', base64: dataUrl, filename: `${_san(username)}/${_san(username)}_bio.json` });
  return { ok: true };
}

// ─────────────────────────────────────────────────────────────────────────────
// QUICK ACTIONS (single post/story on current page)
// ─────────────────────────────────────────────────────────────────────────────

async function quickDownloadPost() {
  const match = location.pathname.match(/\/(p|reel)\/([A-Za-z0-9_-]+)/);
  if (match) {
    const code = match[2];
    try {
      const mediaId = _codeToId(code);
      const res = await igFetch(`https://i.instagram.com/api/v1/media/${mediaId}/info/`);
      if (res.ok) {
        const j    = await res.json();
        const item = j?.items?.[0];
        if (item) {
          const items = _feedItemToItems(item);
          let count = 0;
          for (const m of items) {
            if (!m.url) continue;
            const ext = m.type === 'video' ? '.mp4' : '.jpg';
            await dl(m.url, `${_san(code)}_${++count}${ext}`);
          }
          return { success: true, message: `Downloaded ${count} file(s)!` };
        }
      }
    } catch(_) {}
  }
  // DOM fallback — only the currently playing video or biggest image
  const vid = document.querySelector('video[src]');
  if (vid?.src && !vid.src.startsWith('blob:')) { await dl(vid.src, 'post_' + Date.now() + '.mp4'); return { success: true, message: 'Video download started!' }; }
  // Pick largest non-UI image
  const imgs = [...document.querySelectorAll('img[src*="cdninstagram.com"], img[src*="fbcdn.net"]')]
    .filter(i => i.naturalWidth > 300 && i.naturalHeight > 300)
    .sort((a, b) => (b.naturalWidth * b.naturalHeight) - (a.naturalWidth * a.naturalHeight));
  if (imgs[0]?.src) { await dl(imgs[0].src, 'post_' + Date.now() + '.jpg'); return { success: true, message: 'Photo download started!' }; }
  return { success: false, message: 'No media found. Open the post directly.' };
}

async function quickDownloadStory() {
  // Try the intercepted story items for current user
  const uname = location.pathname.replace(/\//g, '').split('?')[0];
  const items = _stories[uname] || Object.values(_stories).flat();
  if (items.length) {
    const item = items[items.length - 1]; // most recently intercepted = current
    if (item?.url) { await dl(item.url, 'story_' + Date.now() + (item.type === 'video' ? '.mp4' : '.jpg')); return { success: true, message: 'Story downloaded!' }; }
  }
  // DOM fallback — video element only
  const vid = document.querySelector('video');
  if (vid?.src && !vid.src.startsWith('blob:')) { await dl(vid.src, 'story_' + Date.now() + '.mp4'); return { success: true, message: 'Story video downloaded!' }; }
  return { success: false, message: 'No story found. Open the story first so it loads.' };
}

async function getBio() {
  const username = location.pathname.replace(/\//g, '').split('?')[0];
  const info = await fetchProfileInfo(username);
  if (info?.success && info.profile?.bio) return { success: true, bio: info.profile.bio };
  return { success: false, message: 'Navigate to an Instagram profile page.' };
}

// Instagram shortcode → media ID
function _codeToId(code) {
  const MAP = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  let id = BigInt(0);
  for (const c of code) id = id * BigInt(64) + BigInt(MAP.indexOf(c));
  return id.toString();
}

// ─────────────────────────────────────────────────────────────────────────────
// DMs
// ─────────────────────────────────────────────────────────────────────────────

function dmScanInbox() {
  if (_dmInbox.length) return { ok: true, threads: _dmInbox };
  return { ok: false, error: 'Navigate to instagram.com/direct/inbox first, then rescan.' };
}

async function dmLoadThread(threadId) {
  if (!threadId) return { ok: false };
  const thread = _dmThreads[threadId];
  let cursor  = thread?.cursor || null;
  let hasMore = thread ? thread.hasMore : true;
  let pages   = 0;
  while (hasMore && pages < 50) {
    try {
      const res = await igFetch(`https://i.instagram.com/api/v1/direct_v2/threads/${threadId}/?limit=20${cursor ? '&cursor=' + cursor : ''}`);
      if (!res.ok) break;
      const j = await res.json();
      const t = j?.thread; if (!t) break;
      _processDMThread(t);
      await _sleep(100);
      cursor  = t.oldest_cursor || null;
      hasMore = t.has_older     || false;
      pages++;
    } catch(e) { break; }
  }
  await _sleep(150);
  const final = _dmThreads[threadId];
  if (!final) return { ok: false, error: 'Thread not found. Open the conversation first.' };
  return { ok: true, threadId: final.threadId, title: final.title, users: final.users, count: final.messages.length, stats: _dmStats(final.messages), hasMore: final.hasMore };
}

async function dmExport(threadId) {
  const thread = _dmThreads[threadId];
  if (!thread) return { ok: false, error: 'No thread data. Run Load All Pages first.' };
  const slug = _san(thread.title) || threadId;
  const msgs = thread.messages;
  let downloaded = 0;
  for (let i = 0; i < msgs.length; i++) {
    const m = msgs[i]; const pad = String(i).padStart(5, '0');
    if ((m.type === 'photo' || m.type === 'video') && m.mediaUrl) {
      const ext = m.type === 'video' ? '.mp4' : '.jpg';
      m.localFile = `DMs/${slug}/${pad}_${m.type}_${m.id}${ext}`;
      await dl(m.mediaUrl, m.localFile); downloaded++; await _sleep(200);
    }
    if (m.type === 'voice' && m.mediaUrl) {
      m.localFile = `DMs/${slug}/${pad}_voice_${m.id}.m4a`;
      await dl(m.mediaUrl, m.localFile); downloaded++; await _sleep(200);
    }
  }
  const exportObj = { exportedAt: new Date().toISOString(), threadId: thread.threadId, title: thread.title, participants: thread.users, totalMessages: msgs.length, mediaDownloaded: downloaded, note: 'Reel shares stored as permalinks only.', messages: msgs };
  const dataUrl = await _toBase64(new Blob([JSON.stringify(exportObj, null, 2)], { type: 'application/json' }));
  chrome.runtime.sendMessage({ action: 'downloadBase64', base64: dataUrl, filename: `DMs/${slug}/${slug}_conversation.json` });
  return { ok: true, messages: msgs.length, downloaded };
}

function _processDMThread(t) {
  const tid = t.thread_id;
  if (!_dmThreads[tid]) _dmThreads[tid] = { threadId: tid, title: _dmTitle(t), users: (t.users||[]).map(u=>({id:u.pk,username:u.username,fullName:u.full_name})), messages: [], cursor: null, hasMore: true };
  const thread = _dmThreads[tid];
  for (const item of (t.items||[])) {
    if (!thread.messages.find(m => m.id === item.item_id)) thread.messages.push(_normDMItem(item));
  }
  thread.cursor  = t.oldest_cursor || null;
  thread.hasMore = t.has_older     || false;
  thread.messages.sort((a, b) => Number(a.ts) - Number(b.ts));
}

function _normDMItem(item) {
  const base = { id: item.item_id, ts: item.timestamp, date: new Date(Number(item.timestamp)/1000).toISOString(), senderId: item.user_id, type: item.item_type, text: null, mediaUrl: null, localFile: null, reelUrl: null, storyUrl: null, linkUrl: null, reactions: (item.reactions?.emojis||[]).map(r=>({emoji:r.unicode,userId:r.sender_id})) };
  switch (item.item_type) {
    case 'text': base.text = item.text; break;
    case 'media': case 'media_share': { const m=item.media||item.visual_media?.media||{}; const v=m.media_type===2; base.type=v?'video':'photo'; base.mediaUrl=v?_bestVideo(m.video_versions):_bestImage(m.image_versions2); base.caption=m.caption?.text||null; break; }
    case 'reel_share': { const r=item.reel_share?.media||{}; base.type='reel'; base.reelUrl=(r.code||r.shortcode)?`https://www.instagram.com/reel/${r.code||r.shortcode}/`:null; base.text=item.reel_share?.text||null; break; }
    case 'story_share': { const s=item.story_share?.media||{}; base.type='story_share'; base.storyUrl=s.id?`https://www.instagram.com/stories/${s.user?.username}/${s.id}/`:null; base.text=item.story_share?.text||null; break; }
    case 'link': { const lc=item.link?.link_context||{}; base.type='link'; base.linkUrl=lc.link_url||item.link?.text||null; base.text=item.link?.text||null; break; }
    case 'voice_media': { const vm=item.voice_media?.media||{}; base.type='voice'; base.mediaUrl=vm.audio?.audio_src||null; base.duration=vm.audio?.duration||null; break; }
    case 'animated_media': base.type='gif'; base.mediaUrl=item.animated_media?.images?.fixed_height?.url||null; break;
    case 'like': base.type='like'; base.text='❤️'; break;
    default: base.type=item.item_type||'unknown'; base.raw=item;
  }
  return base;
}

function _dmTitle(t) { if(t.thread_title?.trim()) return t.thread_title.trim(); return (t.users||[]).map(u=>u.username||u.full_name).filter(Boolean).join(', ')||t.thread_id||'conversation'; }
function _dmStats(msgs) { const s={text:0,photo:0,video:0,reel:0,voice:0,link:0,other:0}; for(const m of msgs) s[m.type]!==undefined?s[m.type]++:s.other++; return s; }

// ─────────────────────────────────────────────────────────────────────────────
// UTILS
// ─────────────────────────────────────────────────────────────────────────────

function _san(s) { return (s||'file').replace(/[^a-z0-9_\-\.]/gi,'_').slice(0,80); }
function _sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function _toBase64(blob) { return new Promise((res,rej)=>{ const r=new FileReader(); r.onload=()=>res(r.result); r.onerror=rej; r.readAsDataURL(blob); }); }
