// background.js — service worker v3
// Real downloads: CDN URLs, base64/blobs, ZIP assembly via JSZip

// JSZip bundled locally — no CDN dependency
importScripts('../libs/jszip.min.js');

// Per-session ZIP buffers: zipKey → { zip, files[] }
const _zips = {};

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    switch (msg.action) {

      case 'download':
        sendResponse(await handleDownload(msg.url, msg.filename));
        break;

      case 'downloadBase64':
        sendResponse(await handleBase64Download(msg.base64, msg.filename));
        break;

      case 'fetchCors':
        sendResponse(await fetchCors(msg.url));
        break;

      case 'probeCors':
        sendResponse(await probeCors(msg.url));
        break;

      // ZIP: add a remote URL as a file inside the ZIP
      case 'zipAddUrl': {
        const { zipKey, url, filename } = msg;
        if (!_zips[zipKey]) _zips[zipKey] = { zip: new JSZip(), files: [] };
        try {
          const res  = await fetch(url);
          const buf  = await res.arrayBuffer();
          _zips[zipKey].zip.file(filename, buf);
          _zips[zipKey].files.push(filename);
          sendResponse({ ok: true, count: _zips[zipKey].files.length });
        } catch(e) {
          sendResponse({ ok: false, error: e.message });
        }
        break;
      }

      // ZIP: add base64/data-url content as a file
      case 'zipAddBase64': {
        const { zipKey, base64, filename } = msg;
        if (!_zips[zipKey]) _zips[zipKey] = { zip: new JSZip(), files: [] };
        try {
          // strip data:...;base64, prefix
          const b64 = base64.includes(',') ? base64.split(',')[1] : base64;
          _zips[zipKey].zip.file(filename, b64, { base64: true });
          _zips[zipKey].files.push(filename);
          sendResponse({ ok: true, count: _zips[zipKey].files.length });
        } catch(e) {
          sendResponse({ ok: false, error: e.message });
        }
        break;
      }

      // ZIP: finalize and trigger download
      case 'zipFinalize': {
        const { zipKey, zipFilename } = msg;
        const entry = _zips[zipKey];
        if (!entry) { sendResponse({ ok: false, error: 'No zip found for key: ' + zipKey }); break; }
        try {
          const blob    = await entry.zip.generateAsync({ type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 6 } });
          const dataUrl = await blobToBase64SW(blob);
          await chrome.downloads.download({
            url:      dataUrl,
            filename: sanitizeName(zipFilename || zipKey + '.zip'),
            saveAs:   false,
          });
          delete _zips[zipKey];
          sendResponse({ ok: true, files: entry.files.length });
        } catch(e) {
          sendResponse({ ok: false, error: e.message });
        }
        break;
      }

      default:
        sendResponse({ ok: false, error: 'Unknown action: ' + msg.action });
    }
  })();
  return true; // async
});

// ─── Direct CDN download ──────────────────────────────────────────────────────
async function handleDownload(url, filename) {
  if (!url) return { ok: false, error: 'No URL' };
  filename = sanitizeName(filename || 'eloe_file');

  if (url.startsWith('blob:') || url.startsWith('data:')) {
    console.warn('[eloe] blob/data URL sent to handleDownload — use downloadBase64 instead');
    return { ok: false, error: 'Use downloadBase64 for blob/data URLs' };
  }

  try {
    const id = await chrome.downloads.download({
      url,
      filename: 'eloe/' + filename,
      saveAs:   false,
    });
    return { ok: true, downloadId: id };
  } catch(e) {
    console.error('[eloe] Download failed:', filename, e.message);
    // Retry without subfolder path
    try {
      const id = await chrome.downloads.download({ url, saveAs: false });
      return { ok: true, downloadId: id };
    } catch(e2) {
      return { ok: false, error: e2.message };
    }
  }
}

// ─── Base64 / data URL download ───────────────────────────────────────────────
async function handleBase64Download(base64, filename) {
  if (!base64) return { ok: false, error: 'No data' };
  filename = sanitizeName(filename || 'eloe_file');
  try {
    const id = await chrome.downloads.download({
      url:      base64,
      filename: 'eloe/' + filename,
      saveAs:   false,
    });
    return { ok: true, downloadId: id };
  } catch(e) {
    console.error('[eloe] Base64 download failed:', filename, e.message);
    return { ok: false, error: e.message };
  }
}

// ─── CORS helpers ─────────────────────────────────────────────────────────────
async function probeCors(url) {
  try {
    const res = await fetch(url, { method: 'HEAD' });
    return { ok: res.ok, status: res.status };
  } catch(e) {
    return { ok: false, error: e.message };
  }
}

async function fetchCors(url) {
  try {
    const res  = await fetch(url);
    const blob = await res.blob();
    return { ok: true, type: blob.type, size: blob.size };
  } catch(e) {
    return { ok: false, error: e.message };
  }
}

// ─── Util ─────────────────────────────────────────────────────────────────────
function sanitizeName(s) {
  return String(s || 'file')
    .replace(/[<>:"\\|?*\x00-\x1F]/g, '_')
    .slice(0, 200);
}

function blobToBase64SW(blob) {
  return new Promise((res, rej) => {
    const reader = new FileReader();
    reader.onload  = () => res(reader.result);
    reader.onerror = rej;
    reader.readAsDataURL(blob);
  });
}

// ─── Context menu ─────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus?.create({
    id:                  'eloe-dl',
    title:               '⬇ Download with eloe',
    contexts:            ['image', 'video', 'link'],
    documentUrlPatterns: ['https://www.instagram.com/*'],
  });
});

chrome.contextMenus?.onClicked.addListener((info) => {
  if (info.menuItemId !== 'eloe-dl') return;
  const url = info.srcUrl || info.linkUrl;
  if (!url) return;
  handleDownload(url, 'eloe_' + Date.now() + (url.includes('.mp4') ? '.mp4' : '.jpg'));
});
